"""PS5 & Keyboard-Controlled Play Script for Kutta-Flat with Live Motor Output.

Launches the `Kutta-Flat` environment with:
  - Direct Joystick or Keyboard control over cmd_vel (lin_x, lin_y, ang_z).
  - Target joint angles are extracted and published to a socket (127.0.0.1:50000).
  - Integrates the physical motor CAN bus and homing routines, launching them 
    as a background process automatically.

Usage:
  python scripts/run_live_motors.py --checkpoint /path/to/model_700.pt
  python scripts/run_live_motors.py --keyboard --checkpoint /path/to/model_700.pt
"""

from __future__ import annotations

import argparse
import glob
import os
import sys
import threading
import socket
import pickle
import math
import time
import json
import queue
import multiprocessing as mp
from multiprocessing.queues import Queue as MpQueue
from multiprocessing.synchronize import Event as MpEvent
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import torch

# ── mjlab / viewer imports ───────────────────────────────────────────────────
from mjlab.envs import ManagerBasedRlEnv
from mjlab.rl import MjlabOnPolicyRunner, RslRlVecEnvWrapper
from mjlab.tasks.registry import load_env_cfg, load_rl_cfg, load_runner_cls
from mjlab.utils.torch import configure_torch_backends
from mjlab.viewer import NativeMujocoViewer

# =============================================================================
# ── INTEGRATED MOTOR CONTROL SERVER ──────────────────────────────────────────
# =============================================================================
# (Contains the user-provided physical motor homing and socket receiver code)
# =============================================================================

LIVE_SOCKET_HOST = "127.0.0.1"
LIVE_SOCKET_PORT = 50000
LIVE_QUEUE_MAXSIZE = 1
MOTOR_CONFIG_PATH = "motor_config.json"

LEG_ORDER: Tuple[str, str, str, str] = ("fl", "bl", "fr", "br")
LegPayload = Dict[str, List[float]]
MotorCommandConfig = Dict[int, Dict[str, float | bool]]

MAX_LIVE_DEG_PER_S = 50.0

CALIBRATION_REQUIRED = True  

CURRENT_LOG_PATH = "/home/byte/ak60_motor_control/multiprocess_code/all_4_legs/cur_test/motor_currents.csv"
CURRENT_LOG_HZ = 5.0
TEMP_LOG_PATH = "/home/byte/ak60_motor_control/multiprocess_code/all_4_legs/cur_test/motor_temps.csv"
TEMP_LOG_HZ = 5.0

def _get_can_config():
    # Only import these when actually running the motor server, 
    # so we don't crash if the user runs the script without the modules in pythonpath in Sim-only mode.
    try:
        from homing_controller import HomingMotorConfig
    except ImportError:
        return {}

    return {
        "can0": {
            "phase1": [
                HomingMotorConfig(5, -60.0, -1.0, 4.0, 65.0),
                HomingMotorConfig(6, 10.0, 1.0, 5.0, -38.0),
                HomingMotorConfig(4, 60.0, 1.0, 4.0, -60.0),
            ],
            "phase2": [
                HomingMotorConfig(2, -60.0, -1.0, 4.0, 65.0),
                HomingMotorConfig(3, 10.0, 1.0, 4.5, -38.0),
                HomingMotorConfig(1, 60.0, 1.0, 4.0, -60.0),
            ],
        },
        "can1": {
            "phase1": [
                HomingMotorConfig(8, 60.0, 1.0, 4.0, -65.0),
                HomingMotorConfig(9, -10.0, -1.0, 5.0, 38.0),
                HomingMotorConfig(7, -60.0, -1.0, 4.0, 60.0),
            ],
            "phase2": [
                HomingMotorConfig(11, 60.0, 1.0, 4.0, -65.0),
                HomingMotorConfig(12, -10.0, -1.0, 5.0, 38.0),
                HomingMotorConfig(10, -60.0, -1.0, 4.0, 60.0),
            ],
        },
    }

def collect_motor_ids(bus_cfg: dict) -> List[int]:
    ids = []
    for phase_name in ("phase1", "phase2"):
        ids.extend(cfg.motor_id for cfg in bus_cfg[phase_name])
    return sorted(set(ids))

def hold_until_both_phase1_done(controller, my_done_event, other_done_event, stop_event):
    my_done_event.set()
    while not stop_event.is_set():
        if other_done_event.is_set():
            return True
        controller.hold_all_once()
        time.sleep(controller.tuning.loop_dt)
    return False

def hold_until_takeover(controller, takeover_event, stop_event):
    while not stop_event.is_set() and not takeover_event.is_set():
        controller.hold_all_once()
        time.sleep(controller.tuning.loop_dt)

def controller_thread_entry(controller, my_phase1_done, other_phase1_done, my_phase2_done, takeover_event, stop_event, errors):
    channel = controller.runtime.channel
    try:
        if controller.phase1_config:
            controller._run_phase(
                sequence_ids=[cfg.motor_id for cfg in controller.phase1_config],
                hold_at_nudge_ids=set(),
                phase_name="PHASE1",
                stop_event=stop_event,
            )

        if not hold_until_both_phase1_done(controller, my_phase1_done, other_phase1_done, stop_event):
            return

        if stop_event.is_set():
            return

        if controller.phase2_config:
            controller._run_phase(
                sequence_ids=[cfg.motor_id for cfg in controller.phase2_config],
                hold_at_nudge_ids=set(),
                phase_name="PHASE2",
                stop_event=stop_event,
            )

        my_phase2_done.set()
        hold_until_takeover(controller, takeover_event, stop_event)

    except Exception as exc:
        errors.append(f"{channel}: {exc}")
        stop_event.set()
        my_phase1_done.set()
        other_phase1_done.set()
        my_phase2_done.set()
        takeover_event.set()

def load_motor_command_config(path: str) -> MotorCommandConfig:
    with open(path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    motors = raw.get("motors")
    if not isinstance(motors, dict):
        raise ValueError("motor_config.json must contain a top-level 'motors' object")

    config: MotorCommandConfig = {}
    for motor_id in range(1, 13):
        entry = motors.get(str(motor_id))
        if not isinstance(entry, dict):
            raise ValueError(f"motor_config.json missing config for motor {motor_id}")

        config[motor_id] = {
            "kp": float(entry["kp"]),
            "kd": float(entry["kd"]),
            "flipped": bool(entry["flipped"]),
            "gear_ratio": float(entry["gear_ratio"]),
        }
    return config

def validate_leg_payload(payload: Any) -> LegPayload:
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict with keys: fl, bl, fr, br")
    normalized: LegPayload = {}
    for leg in LEG_ORDER:
        if leg not in payload:
            raise ValueError(f"missing leg '{leg}' in payload")
        values = payload[leg]
        if not isinstance(values, (list, tuple)):
            raise ValueError(f"payload['{leg}'] must be a list or tuple")
        if len(values) != 3:
            raise ValueError(f"payload['{leg}'] must contain exactly 3 angles")
        normalized[leg] = [float(v) for v in values]
    return normalized

def flatten_leg_payload(payload: LegPayload) -> List[float]:
    flat: List[float] = []
    for leg in LEG_ORDER:
        flat.extend(payload[leg])
    return flat

def transform_live_angles(raw_angles_deg: List[float], motor_config: MotorCommandConfig) -> Dict[int, float]:
    if len(raw_angles_deg) != 12:
        raise ValueError(f"expected 12 motor angles, received {len(raw_angles_deg)}")
    transformed: Dict[int, float] = {}
    for motor_id, raw_angle_deg in enumerate(raw_angles_deg, start=1):
        cfg = motor_config[motor_id]
        angle_deg = float(raw_angle_deg)
        if bool(cfg["flipped"]):
            angle_deg = -angle_deg
        angle_deg *= float(cfg["gear_ratio"])
        transformed[motor_id] = angle_deg
    return transformed

def runtime_for_motor_id(motor_id: int, rt0, rt1):
    if 1 <= motor_id <= 6:
        return rt0
    if 7 <= motor_id <= 12:
        return rt1
    raise ValueError(f"invalid motor_id {motor_id}")

def send_live_targets(rt0, rt1, targets_deg: Dict[int, float], motor_config: MotorCommandConfig):
    for motor_id in range(1, 13):
        cfg = motor_config[motor_id]
        runtime = runtime_for_motor_id(motor_id, rt0, rt1)
        runtime.send_position_deg(
            motor_id,
            targets_deg[motor_id],
            kp=float(cfg["kp"]),
            kd=float(cfg["kd"]),
            torque=0.0,
        )

def drain_latest_packet(live_queue: MpQueue) -> Optional[LegPayload]:
    latest = None
    while True:
        try:
            latest = live_queue.get_nowait()
        except queue.Empty:
            break
    return latest

def limit_target_step(current_cmd_deg: float, requested_deg: float, max_deg_per_s: float, dt: float) -> float:
    max_step = max_deg_per_s * dt
    delta = requested_deg - current_cmd_deg
    if delta > max_step:
        return current_cmd_deg + max_step
    if delta < -max_step:
        return current_cmd_deg - max_step
    return requested_deg

def initialize_live_command_state(rt0, rt1) -> Dict[int, float]:
    live_cmd_deg: Dict[int, float] = {}
    for motor_id in range(1, 13):
        runtime = runtime_for_motor_id(motor_id, rt0, rt1)
        st = runtime.get_state_copy(motor_id)
        live_cmd_deg[motor_id] = st.position_deg
    return live_cmd_deg

def current_logger_thread_entry(rt0, rt1, stop_event: threading.Event, log_path: str = CURRENT_LOG_PATH, log_hz: float = CURRENT_LOG_HZ) -> None:
    log_dt = 1.0 / log_hz
    motor_ids = list(range(1, 13))
    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a", buffering=1, encoding="utf-8") as fh:
            fh.seek(0, 2)
            if fh.tell() == 0:
                header = "timestamp_s," + ",".join(f"m{i}_a" for i in motor_ids)
                fh.write(header + "\n")
            while not stop_event.is_set():
                t_start = time.monotonic()
                ts = time.time()
                currents: List[float] = []
                for motor_id in motor_ids:
                    runtime = runtime_for_motor_id(motor_id, rt0, rt1)
                    try:
                        state = runtime.get_state_copy(motor_id)
                        currents.append(round(state.current_A, 4))
                    except Exception:
                        currents.append(float("nan"))
                row = f"{ts:.4f}," + ",".join(str(c) for c in currents)
                fh.write(row + "\n")
                elapsed = time.monotonic() - t_start
                sleep_for = log_dt - elapsed
                if sleep_for > 0:
                    time.sleep(sleep_for)
    except Exception as exc:
        print(f"[CurrentLogger] Error: {exc}", flush=True)

def temp_logger_thread_entry(rt0, rt1, stop_event: threading.Event, log_path: str = TEMP_LOG_PATH, log_hz: float = TEMP_LOG_HZ) -> None:
    log_dt = 1.0 / log_hz
    motor_ids = list(range(1, 13))
    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a", buffering=1, encoding="utf-8") as fh:
            fh.seek(0, 2)
            if fh.tell() == 0:
                header = "timestamp_s," + ",".join(f"m{i}_c" for i in motor_ids)
                fh.write(header + "\n")
            while not stop_event.is_set():
                t_start = time.monotonic()
                ts = time.time()
                temps: List[float] = []
                for motor_id in motor_ids:
                    runtime = runtime_for_motor_id(motor_id, rt0, rt1)
                    try:
                        state = runtime.get_state_copy(motor_id)
                        temps.append(round(state.temperature_C, 4))
                    except Exception:
                        temps.append(float("nan"))
                row = f"{ts:.4f}," + ",".join(str(t) for t in temps)
                fh.write(row + "\n")
                elapsed = time.monotonic() - t_start
                sleep_for = log_dt - elapsed
                if sleep_for > 0:
                    time.sleep(sleep_for)
    except Exception as exc:
        print(f"[TempLogger] Error: {exc}", flush=True)

def socket_listener_process(dest_queue: MpQueue, stop_event: MpEvent, port: int = LIVE_SOCKET_PORT, host: str = LIVE_SOCKET_HOST):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.settimeout(0.2)
    try:
        server.bind((host, port))
        server.listen(5)
        while not stop_event.is_set():
            try:
                conn, addr = server.accept()
            except socket.timeout:
                continue
            except OSError:
                if stop_event.is_set(): break
                raise

            with conn:
                conn.settimeout(0.2)
                data = bytearray()
                while not stop_event.is_set():
                    try:
                        chunk = conn.recv(4096)
                    except socket.timeout:
                        continue
                    if not chunk:
                        break
                    data.extend(chunk)

            if not data:
                continue

            try:
                payload = pickle.loads(bytes(data))
                packet = validate_leg_payload(payload)
            except Exception as exc:
                continue

            # Clear queue and add latest
            while True:
                try:
                    dest_queue.get_nowait()
                except queue.Empty:
                    break
                except Exception:
                    break
            try:
                dest_queue.put_nowait(packet)
            except Exception:
                pass
    finally:
        server.close()

def run_post_homing_live_control(ctrl0, ctrl1, rt0, rt1, tuning, stop_event, live_queue, motor_config):
    first_live_packet_seen = False
    last_live_targets_deg: Optional[Dict[int, float]] = None
    live_cmd_deg: Dict[int, float] = initialize_live_command_state(rt0, rt1)

    while not stop_event.is_set():
        rt0.refresh_watchdogs(
            feedback_timeout_s=tuning.feedback_timeout_s,
            bus_silence_timeout_s=tuning.bus_silence_timeout_s,
            fault_on_missing_feedback=True,
        )
        rt1.refresh_watchdogs(
            feedback_timeout_s=tuning.feedback_timeout_s,
            bus_silence_timeout_s=tuning.bus_silence_timeout_s,
            fault_on_missing_feedback=True,
        )

        if rt0.faulted:
            raise RuntimeError(rt0.get_fault_summary())
        if rt1.faulted:
            raise RuntimeError(rt1.get_fault_summary())

        leg_packet = drain_latest_packet(live_queue)
        if leg_packet is not None:
            flat_packet = flatten_leg_payload(leg_packet)
            last_live_targets_deg = transform_live_angles(flat_packet, motor_config)
            if not first_live_packet_seen:
                first_live_packet_seen = True

        if not first_live_packet_seen:
            ctrl0.hold_all_once()
            ctrl1.hold_all_once()
        else:
            for motor_id in range(1, 13):
                live_cmd_deg[motor_id] = limit_target_step(
                    current_cmd_deg=live_cmd_deg[motor_id],
                    requested_deg=last_live_targets_deg[motor_id],
                    max_deg_per_s=MAX_LIVE_DEG_PER_S * motor_config[motor_id]["gear_ratio"],
                    dt=tuning.loop_dt,
                )
            send_live_targets(rt0, rt1, live_cmd_deg, motor_config)
        time.sleep(tuning.loop_dt)

def motor_main():
    """Entry point for the background motor control process."""
    try:
        from can_runtime import BusRuntime
        from homing_controller import BusHomingController, ControlTuning
    except ImportError as e:
        print(f"\n[MotorServer] Error importing physical motor libs: {e}")
        print("[MotorServer] Motor server will not run. (Simulation only)")
        return

    CAN_CONFIG = _get_can_config()

    print_lock = threading.Lock()
    stop_event = threading.Event()
    errors: List[str] = []

    can0_phase1_done = threading.Event()
    can1_phase1_done = threading.Event()
    can0_phase2_done = threading.Event()
    can1_phase2_done = threading.Event()
    final_hold_takeover = threading.Event()

    tuning = ControlTuning(
        active_kp=114.0, active_kd=1.2, hold_kp=54.0, hold_kd=0.9, homed_hold_kp=84.0, homed_hold_kd=1.2, loop_hz=100.0,
        min_move_time_s=1.2, seconds_per_deg=0.03, trigger_confirm_s=0.15, trigger_velocity_raw_max=4.0,
        feedback_timeout_s=0.15, bus_silence_timeout_s=0.40, startup_timeout_s=5.0, startup_poll_s=0.01,
        zero_feedback_timeout_s=1.5, zero_position_tolerance_deg=5.0, max_search_time_s=10.0, max_search_travel_deg=220.0,
        status_period_s=0.5, safe_idle_kp=48.0, safe_idle_kd=0.8, nudge_position_tolerance_deg=2.0, nudge_settle_time_s=0.12,
        search_max_vel_deg_s=100.0, search_max_acc_deg_s2=140.0, continuous_search_vel_deg_s=40.0, nudge_max_vel_deg_s=60.0,
        nudge_max_acc_deg_s2=168.0, advance_target_tolerance_deg=2.0, advance_settle_time_s=0.20,
        stall_progress_epsilon_deg=0.25, stall_timeout_s=0.50, wait_log_period_s=1.0, contact_hold_offset_deg=0.5,
        contact_release_move_deg=3.0, contact_stall_vel_max=2.0,
    )

    rt0 = None
    rt1 = None
    live_queue = None
    live_socket_stop = None
    live_socket_process = None

    try:
        can0_ids = collect_motor_ids(CAN_CONFIG["can0"])
        can1_ids = collect_motor_ids(CAN_CONFIG["can1"])

        rt0 = BusRuntime("can0", can0_ids, bitrate=1_000_000)
        rt1 = BusRuntime("can1", can1_ids, bitrate=1_000_000)

        ctrl0 = BusHomingController(
            runtime=rt0, phase1_config=CAN_CONFIG["can0"]["phase1"], phase2_config=CAN_CONFIG["can0"]["phase2"], tuning=tuning, print_lock=print_lock,
        )
        ctrl1 = BusHomingController(
            runtime=rt1, phase1_config=CAN_CONFIG["can1"]["phase1"], phase2_config=CAN_CONFIG["can1"]["phase2"], tuning=tuning, print_lock=print_lock,
        )

        ctrl0.verify_periodic_feedback_and_capture_boot_holds()
        ctrl1.verify_periodic_feedback_and_capture_boot_holds()

        for _ in range(int(tuning.loop_hz)):
            ctrl0.send_idle_hold_once()
            ctrl1.send_idle_hold_once()
            time.sleep(tuning.loop_dt)

        if CALIBRATION_REQUIRED:
            t0 = threading.Thread(target=controller_thread_entry, args=(ctrl0, can0_phase1_done, can1_phase1_done, can0_phase2_done, final_hold_takeover, stop_event, errors), daemon=True)
            t1 = threading.Thread(target=controller_thread_entry, args=(ctrl1, can1_phase1_done, can0_phase1_done, can1_phase2_done, final_hold_takeover, stop_event, errors), daemon=True)
            t0.start()
            t1.start()

            while not stop_event.is_set():
                if errors:
                    raise RuntimeError(" | ".join(errors))
                if can0_phase2_done.is_set() and can1_phase2_done.is_set():
                    break
                time.sleep(tuning.loop_dt)

            for _ in range(5):
                ctrl0.hold_all_once()
                ctrl1.hold_all_once()
                time.sleep(tuning.loop_dt)

            final_hold_takeover.set()
            t0.join()
            t1.join()
            if errors:
                raise RuntimeError(" | ".join(errors))
        else:
            final_hold_takeover.set()

        motor_config = load_motor_command_config(MOTOR_CONFIG_PATH)

        threading.Thread(target=current_logger_thread_entry, args=(rt0, rt1, stop_event), daemon=True, name="CurrentLogger").start()
        threading.Thread(target=temp_logger_thread_entry, args=(rt0, rt1, stop_event), daemon=True, name="TempLogger").start()

        live_queue = mp.Queue(maxsize=LIVE_QUEUE_MAXSIZE)
        live_socket_stop = mp.Event()
        live_socket_process = mp.Process(target=socket_listener_process, args=(live_queue, live_socket_stop, LIVE_SOCKET_PORT, LIVE_SOCKET_HOST), daemon=True)
        live_socket_process.start()

        run_post_homing_live_control(ctrl0=ctrl0, ctrl1=ctrl1, rt0=rt0, rt1=rt1, tuning=tuning, stop_event=stop_event, live_queue=live_queue, motor_config=motor_config)

    except Exception as exc:
        print(f"\n[MotorServer] Error: {exc}")
        stop_event.set()
        final_hold_takeover.set()
    finally:
        if live_socket_stop is not None:
            live_socket_stop.set()
        if live_socket_process is not None:
            live_socket_process.terminate()
        try:
            if rt0 is not None: rt0.disable_all()
        except Exception: pass
        try:
            if rt1 is not None: rt1.disable_all()
        except Exception: pass
        try:
            if rt0 is not None: rt0.stop()
        except Exception: pass
        try:
            if rt1 is not None: rt1.stop()
        except Exception: pass


# =============================================================================
# ── JOYSTICK / KEYBOARD CONTROL & RL VIEWER ──────────────────────────────────
# =============================================================================

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
import pygame

TASK_ID = "Kutta-Flat"

MAX_LIN_VEL_X = 1.5
MAX_LIN_VEL_Y = 0.8
MAX_ANG_VEL_Z = 1.5
DEADBAND = 0.08

AXIS_LX = 0
AXIS_LY = 1
AXIS_RX = 3

BTN_CROSS = 0
BTN_CIRCLE = 1
BTN_SQUARE = 3
BTN_TRIANGLE = 2

class PS5JoystickReader:
    def __init__(self) -> None:
        self._lin_x = 0.0
        self._lin_y = 0.0
        self._ang_z = 0.0
        self._lock  = threading.Lock()
        self._button_events: list[int] = []
        self._btn_lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._joy: Optional[pygame.joystick.Joystick] = None

    def start(self) -> None:
        pygame.init()
        pygame.joystick.init()
        if pygame.joystick.get_count() == 0:
            print("[PS5] WARNING: No joystick detected.")
            return

        self._joy = pygame.joystick.Joystick(0)
        self._joy.init()
        print(f"[PS5] Connected: '{self._joy.get_name()}'")

        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True, name="ps5-joy")
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)
        pygame.quit()

    @property
    def cmd(self) -> tuple[float, float, float]:
        with self._lock:
            return self._lin_x, self._lin_y, self._ang_z

    def pop_button_events(self) -> list[int]:
        with self._btn_lock:
            evts, self._button_events = self._button_events, []
        return evts

    def _run_loop(self) -> None:
        while self._running:
            for evt in pygame.event.get():
                if evt.type == pygame.JOYBUTTONDOWN:
                    with self._btn_lock:
                        self._button_events.append(evt.button)

            if self._joy is not None:
                lin_x = self._apply_deadband(-self._joy.get_axis(AXIS_LY)) * MAX_LIN_VEL_X
                lin_y = self._apply_deadband(-self._joy.get_axis(AXIS_LX)) * MAX_LIN_VEL_Y
                ang_z = self._apply_deadband(-self._joy.get_axis(AXIS_RX)) * MAX_ANG_VEL_Z
                with self._lock:
                    self._lin_x = lin_x
                    self._lin_y = lin_y
                    self._ang_z = ang_z

            time.sleep(0.005)

    @staticmethod
    def _apply_deadband(val: float) -> float:
        if abs(val) < DEADBAND:
            return 0.0
        sign = 1.0 if val > 0 else -1.0
        return sign * (abs(val) - DEADBAND) / (1.0 - DEADBAND)


class KeyboardReader:
    def __init__(self):
        self._lin_x = 0.0
        self._lin_y = 0.0
        self._ang_z = 0.0
        
    def handle_key(self, key: int):
        import glfw 
        step = 0.15
        if key == getattr(glfw, 'KEY_W', 87):
            self._lin_x = min(MAX_LIN_VEL_X, self._lin_x + step)
            print(f"Vx: {self._lin_x:.2f}")
        elif key == getattr(glfw, 'KEY_S', 83):
            self._lin_x = max(-MAX_LIN_VEL_X, self._lin_x - step)
            print(f"Vx: {self._lin_x:.2f}")
        elif key == getattr(glfw, 'KEY_A', 65):
            self._lin_y = min(MAX_LIN_VEL_Y, self._lin_y + step)
            print(f"Vy: {self._lin_y:.2f}")
        elif key == getattr(glfw, 'KEY_D', 68):
            self._lin_y = max(-MAX_LIN_VEL_Y, self._lin_y - step)
            print(f"Vy: {self._lin_y:.2f}")
        elif key == getattr(glfw, 'KEY_LEFT', 263):
            self._ang_z = min(MAX_ANG_VEL_Z, self._ang_z + step)
            print(f"Wz: {self._ang_z:.2f}")
        elif key == getattr(glfw, 'KEY_RIGHT', 262):
            self._ang_z = max(-MAX_ANG_VEL_Z, self._ang_z - step)
            print(f"Wz: {self._ang_z:.2f}")
        elif key == getattr(glfw, 'KEY_SPACE', 32):
            self._lin_x = 0.0
            self._lin_y = 0.0
            self._ang_z = 0.0
            print("STOP")

    @property
    def cmd(self) -> tuple[float, float, float]:
        return self._lin_x, self._lin_y, self._ang_z


class LiveMotorMujocoViewer(NativeMujocoViewer):
    def __init__(self, env, policy, joy, keyboard_control=False, socket_host="127.0.0.1", socket_port=50000, **kwargs):
        super().__init__(env, policy, **kwargs)
        self._joy = joy
        self._kb = KeyboardReader()
        self._use_keyboard = keyboard_control
        self._cmd_term = None
        self._socket_host = socket_host
        self._socket_port = socket_port
        
        # We hook onto user_key_callback for Keyboard input 
        # (This is triggered by the MuJoCo viewer passive UI mechanism)
        if self._use_keyboard:
            print("[Simulator] Using KEYBOARD control:")
            print("  W/S: Forward/Backward")
            print("  A/D: Strafe Left/Right")
            print("  LEFT/RIGHT ARROWS: Turn (Yaw)")
            print("  SPACE: Stop all movement")

    def _user_key_callback_hook(self, key: int):
        if self._use_keyboard:
            self._kb.handle_key(key)
        # Delegate to superclass implementation for pausing/speeding via NativeMujocoViewer callbacks if they existed.

    def setup(self):
        super().setup()
        # Override MuJoCo key callback if using keyboard
        if self._use_keyboard:
            original_cb = self.user_key_callback
            def custom_cb(key):
                self._user_key_callback_hook(key)
                if original_cb:
                    original_cb(key)
            self.user_key_callback = custom_cb

    def _get_cmd_term(self):
        if self._cmd_term is None:
            raw_env: ManagerBasedRlEnv = self.env.unwrapped
            self._cmd_term = raw_env.command_manager.get_term("twist")
        return self._cmd_term

    def step_simulation(self) -> None:
        # Drain button events for PS5 (only if using PS5)
        if not self._use_keyboard and self._joy:
            for btn in self._joy.pop_button_events():
                if btn == BTN_CROSS: self.toggle_pause()
                elif btn == BTN_SQUARE: self.reset_environment()
                elif btn == BTN_CIRCLE: self.increase_speed()
                elif btn == BTN_TRIANGLE: self.decrease_speed()

        if not self._is_paused:
            cmd_source = self._kb if self._use_keyboard else self._joy
            lin_x, lin_y, ang_z = cmd_source.cmd
            
            cmd_term = self._get_cmd_term()
            if cmd_term is not None:
                cmd_term.vel_command_b[:, 0] = lin_x
                cmd_term.vel_command_b[:, 1] = lin_y
                cmd_term.vel_command_b[:, 2] = ang_z

        super().step_simulation()
        
        if not self._is_paused:
            try:
                # Kutta has 12 joints mapped to ctrl based on env_cfgs.py
                sim_data = self.env.unwrapped.sim.data
                ctrl = sim_data.ctrl[self.env_idx].cpu().numpy()
                
                if len(ctrl) >= 12:
                    fl = [math.degrees(c) for c in ctrl[0:3]]
                    bl = [math.degrees(c) for c in ctrl[3:6]]
                    fr = [math.degrees(c) for c in ctrl[6:9]]
                    br = [math.degrees(c) for c in ctrl[9:12]]
                    
                    payload = {"fl": fl, "bl": bl, "fr": fr, "br": br}
                    self._send_payload(payload)
            except Exception:
                pass

    def _send_payload(self, payload: dict) -> None:
        data = pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            with socket.socket(socket.AF_INET, socket.STREAM) as sock: # Changed to SOCK_STREAM later
                pass 
        except Exception:
            pass

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(0.01)
                sock.connect((self._socket_host, self._socket_port))
                sock.sendall(data)
        except Exception:
            pass


def pick_checkpoint(log_root: Path, experiment_name: str) -> Path:
    pattern = str(log_root / experiment_name / "**" / "*.pt")
    candidates = sorted(glob.glob(pattern, recursive=True))

    if not candidates:
        print(f"\n[ERROR] No .pt checkpoints found under: {log_root / experiment_name}")
        sys.exit(1)

    print("\n── Available checkpoints ──────────────────────────────────────")
    for i, c in enumerate(candidates):
        rel = Path(c).relative_to(log_root)
        print(f"  [{i}] {rel}")
        
    while True:
        raw = input("Select checkpoint number (default 0): ").strip()
        if raw == "":
            idx = 0
        elif raw.isdigit() and 0 <= int(raw) < len(candidates):
            idx = int(raw)
        else:
            print(f"  Please enter a number between 0 and {len(candidates)-1}.")
            continue
        chosen = Path(candidates[idx])
        print(f"[INFO] Selected: {chosen}")
        return chosen

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Play Kutta-Flat with PS5/Keyboard control and launch Live Motor Server.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--checkpoint", "-c", metavar="PATH", default=None, help="Path to a .pt checkpoint file.")
    p.add_argument("--no-terminations", action="store_true", help="Disable all episode termination conditions.")
    p.add_argument("--num-envs", "-n", type=int, default=1, help="Number of parallel environments.")
    p.add_argument("--device", default=None, help="Compute device, e.g. 'cuda:0' or 'cpu'.")
    p.add_argument("--keyboard", action="store_true", help="Enable WSAD+Arrows keyboard override instead of PS5.")
    return p.parse_args()


def __motor_server_entry(sys_path):
    import sys
    sys.path = sys_path + sys.path # Ensure paths are available for the subprocess
    motor_main()


def main() -> None:
    args = parse_args()
    
    # ── 1. LAUNCH MOTOR SERVER IN BACKGROUND ──
    # The physical CAN bus homing and socket queue setup
    motor_p = mp.Process(target=__motor_server_entry, args=(sys.path.copy(),), daemon=True)
    motor_p.start()
    
    # ── 2. LAUNCH SIMULATION AND VIEWER ──
    import mjlab.tasks  
    import src.tasks    

    configure_torch_backends()
    device: str = args.device or ("cuda:0" if torch.cuda.is_available() else "cpu")

    env_cfg = load_env_cfg(TASK_ID, play=True)
    agent_cfg = load_rl_cfg(TASK_ID)

    if args.no_terminations:
        env_cfg.terminations = {}
        print("[INFO] All terminations disabled.")

    env_cfg.scene.num_envs = args.num_envs

    if args.checkpoint is not None:
        resume_path = Path(args.checkpoint)
        if not resume_path.exists():
            print(f"[ERROR] Checkpoint not found: {resume_path}")
            sys.exit(1)
        print(f"[INFO] Checkpoint: {resume_path}")
    else:
        log_root = (Path("logs") / "rsl_rl" / agent_cfg.experiment_name).resolve()
        resume_path = pick_checkpoint(log_root, agent_cfg.experiment_name)

    env = ManagerBasedRlEnv(cfg=env_cfg, device=device)
    env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)

    runner_cls = load_runner_cls(TASK_ID) or MjlabOnPolicyRunner
    runner = runner_cls(env, asdict(agent_cfg), device=device)
    runner.load(str(resume_path), load_cfg={"actor": True}, strict=True, map_location=device)
    policy = runner.get_inference_policy(device=device)

    joy = None
    if not args.keyboard:
        joy = PS5JoystickReader()
        joy.start()

    viewer = LiveMotorMujocoViewer(env, policy, joy=joy, keyboard_control=args.keyboard)
    try:
        viewer.run()
    finally:
        if joy:
            joy.stop()
        env.close()

if __name__ == "__main__":
    mp.freeze_support()
    main()
